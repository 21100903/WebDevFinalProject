const {createClient} = supabase;

const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpuY29uanliaWtja3J4ZW13eWN0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTE5NTIzNzUsImV4cCI6MjAyNzUyODM3NX0.G60Ncu3ytm5HFJqre0HnIY-QQ21cWO7OZ17vlhmC3Xc"
const SUPABASE_URL = "https://jnconjybikckrxemwyct.supabase.co"

const connection = createClient(SUPABASE_URL, SUPABASE_KEY);


async function add(){
    
    
    await connection.from('Properties').insert({
        Building_name: document.getElementById("buildingname").value,
        Address: document.getElementById("address").value,
        Building_code: document.getElementById("code").value,
        Building_picture: document.getElementById("picturelink").value
    })
    
    preview(document.getElementById("code").value)
    
}


async function preview(code){
    
    let { data, error } = await connection
    .from('Properties')
    .select('*').eq('Building_code',code)


    document.getElementById('iddisplay').innerHTML = " "
    document.getElementById('buildingnamedisplay').innerHTML = " "
    document.getElementById('addressdisplay').innerHTML = " "
    document.getElementById('buildingcodedisplay').innerHTML = " "        
    document.getElementById('picturelinkdisplay').innerHTML = " "

    let pic = document.createElement('img')
    pic.src = data[0].Building_picture
    pic.alt = data[0].Building_picture
    pic.width = 100
    pic.height = 100

    document.getElementById('iddisplay').appendChild(document.createTextNode(data[0].id))
    document.getElementById('buildingnamedisplay').appendChild(document.createTextNode(data[0].Building_name))
    document.getElementById('addressdisplay').appendChild(document.createTextNode(data[0].Address))
    document.getElementById('buildingcodedisplay').appendChild(document.createTextNode(data[0].Building_code))
    document.getElementById('picturelinkdisplay').appendChild(pic)
    

}


async function displaybuildings(){
    const { data, error } = await connection.from('Properties').select('*')

    console.log(data)

    
    if(data){
        console.log('true')
        
        document.getElementById("innermain").innerHTML = ""
        
        for(let i = 0; i < data.length; i++){
            let node = document.createElement('div')
            node.className = 'listdiv'
            let pic = document.createElement('img')
            pic.width = 100
            pic.height = 100
            pic.src = data[i].Building_picture;
            pic.alt = "pciture"
            pic.className = 'picture'
            node.appendChild(pic)
            node.appendChild(document.createElement('br'))
            node.appendChild(document.createTextNode('ID: ' + data[i].id))
            node.appendChild(document.createElement('br'))
            node.appendChild(document.createTextNode('Building Code: '+data[i].Building_code))
            node.appendChild(document.createElement('br'))
            node.appendChild(document.createTextNode('Building Name: '+data[i].Building_name))
            node.appendChild(document.createElement('br'))
            node.appendChild(document.createTextNode('Building Address: '+data[i].Address))
            node.appendChild(document.createElement('br'))
            document.getElementById("innermain").append(node)
            /*let Delete = document.createElement("button")
            Delete.innerHTML = "delete"
            Delete.onclick = _delete()
            Delete.value = buildingcode
            node.appendChild(Delete)
            console.log(Delete)*/
        }
    }
    if(error){
        console.log('false')
    }

    
}


async function _delete(){
    
    const {error} = await connection.from('Properties').delete().eq('id', document.getElementById('idsearch').value)
    alert("Deleted!")
    
}


async function search(){

    let { data, error } = await connection
    .from('Properties')
    .select("*")
    .eq('id', document.getElementById('idsearch').value)

    console.log(data)
    console.log(error)
    
        if(data[0] != null){
            alert("ID found!")
            console.log(data[0].id)
            console.log(data[0].Building_name)
            console.log(data[0].Building_code)
            console.log(data[0].Building_picture)
            console.log(data[0].Address)
            searchpreview(data[0].id, data[0].Building_name, data[0].Building_code, data[0].Building_picture, data[0].Address)
        }else
        if(data[0] == null){
           alert("ID not found!")
        }
   
}



function searchpreview(id, buildingname, buildingcode, picturelink, address){
    document.getElementById('id').innerHTML = " "
    document.getElementById('buildingnamedisplay').innerHTML = " "
    document.getElementById('addressdisplay').innerHTML = " "
    document.getElementById('buildingcodedisplay').innerHTML = " "        
    document.getElementById('picturelinkdisplay').innerHTML = " "

    let pic = document.createElement('img')
    pic.src = picturelink
    pic.alt = picturelink
    pic.width = 100
    pic.height = 100

    document.getElementById('id').appendChild(document.createTextNode(id))
    document.getElementById('buildingnamedisplay').appendChild(document.createTextNode(buildingname))
    document.getElementById('addressdisplay').appendChild(document.createTextNode(address))
    document.getElementById('buildingcodedisplay').appendChild(document.createTextNode(buildingcode))
    document.getElementById('picturelinkdisplay').appendChild(pic)

}


async function edit(){
    let val = Number(document.getElementById("code").value)
    console.log(val)
    if(Number.isInteger(val)){
        if(document.getElementById("buildingname").value != ""){
            let { BNdata, BNerror } = await connection
            .from('Properties')
            .update({ Building_name: document.getElementById("buildingname").value })
            .eq('id', document.getElementById('idsearch').value)
            .select()
        }else
        console.log(document.getElementById("buildingname").value)
        if(document.getElementById("address").value != ""){
            let { BAdata, BAerror } = await connection
            .from('Properties')
            .update({ Address: document.getElementById("address").value })
            .eq('id', document.getElementById('idsearch').value)
            .select()
        }else
        console.log(document.getElementById("address").value)
        if(document.getElementById("code").value != ""){
            let { BCdata, BCerror } = await connection
            .from('Properties')
            .update({ Building_code: document.getElementById("code").value })
            .eq('id', document.getElementById('idsearch').value)
            .select()
        
        }else
        console.log(document.getElementById("code").value)
        if(document.getElementById("picturelink").value != ""){
            let { PLdata, PLerror } = await connection
            .from('Properties')
            .update({ Building_picture: document.getElementById("picturelink").value })
            .eq('id', document.getElementById('idsearch').value)
            .select()
        }else
        console.log(document.getElementById("picturelink").value)
        alert('Details have been updated!')
    }else
    if(Number.isNaN(val)){
        alert("Building Code must be an integer!")
    }

    let { data, error } = await connection
    .from('Properties')
    .select("*")
    .eq('id', document.getElementById('idsearch').value)

    searchpreview(data[0].id, data[0].Building_name, data[0].Building_code, data[0].Building_picture, data[0].Address)

}

